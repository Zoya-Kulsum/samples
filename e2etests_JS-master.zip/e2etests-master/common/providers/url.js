/**
 * Created by adnanghaffar on 31/08.
 */
'use strict';
var RootUrl = function() {
    var _this = this;
    _this.rootUrl = '.com';
};

module.exports = new RootUrl();
