from common.config import *
def signUpPageData():
    data={}
    data['signUpButton']='._3sz-Jorbvi2LDO38TpQcMl nav._1AG8nKzRcS5hWYKhv_1_fo .nav>li>a'
    data['signUpUrl']= '%s/signup'%(mainUrl)
    data['logOutUrl']='%s/logout'%(mainUrl)
    data['signUpButton2']='._2NrQqodh9iGxKj12Bqk7ZJ button'
    data['errors']='mkbVv4piLCk5Xfc8OFsU4'
    return data



