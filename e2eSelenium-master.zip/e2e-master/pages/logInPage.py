from common.config import *
def logInPageData():
    data={}
    data['logInButton']='btn-fancy-green'
    data['logInUrl']= '%s/login'%(mainUrl)
    data['logOutUrl']='%s/logout'%(mainUrl)
    data['logInRedirectUrl']='%s/editor?module='%(mainUrl)
    data['errors']='_2YsAR-q1EqlLr-6LOo3hgd'
    data['rememberMe']='_3ZpRrnAcsW67wANGmnTk-h'
    data['redirectTextDiv']='title'
    data['redirectText']='WHAT ARE YOU CAPTURING?'
    return data

