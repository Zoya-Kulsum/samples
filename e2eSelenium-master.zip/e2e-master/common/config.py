import  os
dir = os.getcwd()
chromeDriverPath = "%s/common/driver/chromedriver"%(dir)
mainUrl="https://www.iorad.com"
