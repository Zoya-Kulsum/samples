def logInData():
    logIn={}
    logIn['email'] = "AdnanGhaffar@gmail.com"
    logIn['invalidEmail'] = "AdnanGhaffargmail.com"
    logIn['password'] = "TestPassword"
    logIn['invalidPassword'] = "Password"
    return logIn
