def forgotPasswordData():
    fpass={}
    fpass['email'] = "AdnanGhaffar@gmail.com"
    fpass['invalidEmail'] = "AdnanGhaffar.com"
    fpass['unRegisteredEmail'] = "AdnanGhaffar4321@gmail.com"
    fpass['password'] = "TestPassword"
    fpass['confirmPassword'] = "TestPassword"
    return fpass